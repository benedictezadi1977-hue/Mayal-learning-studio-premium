MAYAL LEARNING STUDIO – PREMIUM WEBSITE

1. Upload index.html to your existing Vercel project, replacing the old index.html.
2. Deploy the project.
3. Your domain mayaltutoring.com will continue pointing to the Vercel project.

Before publishing, review:
- Prices: $55, $200 monthly, and $35.
- Email: contact@mayaltutoring.com.
- Online/in-person availability.

The contact form currently opens the visitor's email app. It can later be connected to Calendly, Formspree, Tally, or Stripe Payment Links.
